// server/index.ts
import { createServer } from "node:http";
import { readFile, mkdir, writeFile, rename } from "node:fs/promises";
import { join } from "node:path";
import { randomInt as randomInt2, timingSafeEqual } from "node:crypto";

// src/development.ts
var developmentKinds = ["knight", "roads", "plenty", "monopoly", "church", "market", "school", "reservoir", "festival"];
var developmentCost = { couro: 1, pedra: 1, milho: 1 };
var developmentInfo = {
  knight: { title: "Cangaceiro", description: "Mova o Cobrador e receba uma carta de um advers\xE1rio vizinho. Conta para o Maior Grupo de Cangaceiros.", count: 14, art: 0, prestige: false },
  roads: { title: "Mutir\xE3o", description: "Construa at\xE9 duas estradas gr\xE1tis, respeitando sua rede e o limite de pe\xE7as.", count: 2, art: 1, prestige: false },
  plenty: { title: "Safra Generosa", description: "Escolha dois recursos dispon\xEDveis no banco. Podem ser iguais.", count: 2, art: 2, prestige: false },
  monopoly: { title: "Acordo do Coronel", description: "Escolha um recurso e receba todas as cartas desse tipo que os advers\xE1rios possuem.", count: 2, art: 3, prestige: false },
  church: { title: "Igreja do Sert\xE3o", description: "Vale 1 ponto de prest\xEDgio. Fica oculta dos advers\xE1rios at\xE9 o fim da partida.", count: 1, art: 4, prestige: true },
  market: { title: "Feira Livre", description: "Vale 1 ponto de prest\xEDgio. Fica oculta dos advers\xE1rios at\xE9 o fim da partida.", count: 1, art: 5, prestige: true },
  school: { title: "Escola Rural", description: "Vale 1 ponto de prest\xEDgio. Fica oculta dos advers\xE1rios at\xE9 o fim da partida.", count: 1, art: 6, prestige: true },
  reservoir: { title: "A\xE7ude Comunit\xE1rio", description: "Vale 1 ponto de prest\xEDgio. Fica oculta dos advers\xE1rios at\xE9 o fim da partida.", count: 1, art: 7, prestige: true },
  festival: { title: "Festa de S\xE3o Jo\xE3o", description: "Vale 1 ponto de prest\xEDgio. Fica oculta dos advers\xE1rios at\xE9 o fim da partida.", count: 1, art: 8, prestige: true }
};
function createDevelopment(seed = 0, players = 3) {
  const deck = developmentKinds.flatMap((kind) => Array(developmentInfo[kind].count).fill(kind));
  let value = (seed ^ 747796405) >>> 0;
  for (let i = deck.length - 1; i > 0; i--) {
    value = Math.imul(value, 1664525) + 1013904223 >>> 0;
    const j = Math.floor(value / 4294967296 * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return { deck, hands: Array.from({ length: players }, () => []), discard: [], armyOwner: null, freeRoads: null, robberReturn: null };
}
var developmentTurn = (s) => s.onlineTurn ?? (s.round - 1) * (s.players?.length ?? 3) + s.current;
function validateDevelopment(value, turn, current, phase, players = 3) {
  if (value === void 0) return phase !== "free-roads";
  try {
    const d = value;
    if (!d || !Array.isArray(d.deck) || !Array.isArray(d.hands) || d.hands.length !== players || d.hands.some((h) => !Array.isArray(h)) || !Array.isArray(d.discard)) return false;
    const known = (k) => developmentKinds.includes(k), counts = Object.fromEntries(developmentKinds.map((k) => [k, 0]));
    for (const kind of d.deck) {
      if (!known(kind)) return false;
      counts[kind]++;
    }
    const ids = /* @__PURE__ */ new Set(), played = /* @__PURE__ */ new Set();
    const card = (c, owner) => {
      if (!c || !known(c.kind) || !Number.isInteger(c.id) || c.id < 0 || c.id >= 25 || ids.has(c.id) || !Number.isInteger(c.boughtTurn) || c.boughtTurn < 0 || c.boughtTurn > turn || c.boughtTurn % players !== owner) return false;
      ids.add(c.id);
      counts[c.kind]++;
      return true;
    };
    for (let owner = 0; owner < players; owner++) for (const c of d.hands[owner]) if (!card(c, owner)) return false;
    for (const c of d.discard) {
      if (!Number.isInteger(c.owner) || c.owner < 0 || c.owner >= players || !card(c, c.owner) || developmentInfo[c.kind].prestige || !Number.isInteger(c.playedTurn) || c.playedTurn <= c.boughtTurn || c.playedTurn > turn || c.playedTurn % players !== c.owner || played.has(c.playedTurn)) return false;
      played.add(c.playedTurn);
    }
    if (developmentKinds.some((k) => counts[k] !== developmentInfo[k].count) || ids.size !== 25 - d.deck.length || [...ids].some((id) => id >= ids.size)) return false;
    const army = Array.from({ length: players }, (_, p) => d.discard.filter((c) => c.kind === "knight" && c.owner === p).length), max = Math.max(...army);
    if (d.armyOwner !== null && (!Number.isInteger(d.armyOwner) || d.armyOwner < 0 || d.armyOwner >= players || army[d.armyOwner] < 3 || army[d.armyOwner] !== max)) return false;
    if (d.armyOwner === null && max >= 3 && army.filter((n) => n === max).length === 1) return false;
    if (d.freeRoads !== null) {
      const f = d.freeRoads;
      if (!f || f.owner !== current || ![1, 2].includes(f.left) || !["roll", "build"].includes(f.returnPhase) || phase !== "free-roads" || !d.discard.some((c) => c.kind === "roads" && c.owner === current && c.playedTurn === turn)) return false;
    } else if (phase === "free-roads") return false;
    if (d.robberReturn !== null && (!["roll", "build"].includes(d.robberReturn) || phase !== "robber" || !d.discard.some((c) => c.kind === "knight" && c.owner === current && c.playedTurn === turn))) return false;
    return !(d.freeRoads && d.robberReturn);
  } catch {
    return false;
  }
}

// server/room.ts
import { randomBytes, randomInt } from "node:crypto";

// src/layout.ts
var boardRows = [
  ["caatinga", "barreiro", "serrote"],
  ["rocado", "pastagem", "caatinga", "barreiro"],
  ["serrote", "rocado", "terra-seca", "pastagem", "caatinga"],
  ["barreiro", "pastagem", "rocado", "serrote"],
  ["caatinga", "pastagem", "rocado"]
];
var rowLengths = (size = "classic") => size === "double" ? [6, 7, 8, 9, 8] : [3, 4, 5, 4, 3];

// src/trade-stops.ts
function createTradeStops(map2) {
  const boundary = map2.edges.filter((e) => map2.nodes[e.a].tiles.filter((t) => map2.nodes[e.b].tiles.includes(t)).length === 1).sort((a, b) => {
    const angle = (e) => Math.atan2(map2.nodes[e.a].z + map2.nodes[e.b].z, map2.nodes[e.a].x + map2.nodes[e.b].x);
    return angle(a) - angle(b);
  });
  const types = [null, "lenha", null, "barro", "pedra", null, "milho", null, "couro"];
  return types.map((resource2, i) => {
    const edge = boundary[Math.floor(i * boundary.length / 9)], a = map2.nodes[edge.a], b = map2.nodes[edge.b], x = (a.x + b.x) / 2, z = (a.z + b.z) / 2, length = Math.hypot(x, z);
    return { id: `tropeiro-${i + 1}`, resource: resource2, edge: edge.id, nodes: [edge.a, edge.b], x: x + x / length * 1.15, z: z + z / length * 1.15, angle: Math.atan2(x, z) };
  });
}

// src/sertao-rules.ts
var resources = ["couro", "lenha", "barro", "pedra", "milho"];
var costs = {
  road: { lenha: 1, barro: 1 },
  settlement: { lenha: 1, barro: 1, couro: 1, milho: 1 },
  city: { pedra: 3, milho: 2 }
};
var names = { couro: "Couro", lenha: "Lenha", barro: "Barro", pedra: "Pedra", milho: "Milho" };
var terrainResource = { pastagem: "couro", caatinga: "lenha", barreiro: "barro", serrote: "pedra", rocado: "milho", "terra-seca": null };
var TARGET = 8;
var setupFor = (s) => {
  const ids = s.players.map((_, i) => i);
  return [...ids, ...ids.slice().reverse()];
};
var bankCapacity = (s) => s.mapSize === "double" ? 38 : 19;
function makeMap(rows = boardRows, numbers = [5, 2, 6, 3, 8, 10, 9, 12, 11, 4, 8, 10, 9, 4, 5, 6, 3, 11]) {
  const tiles = [], nodes = [], edges = [], nodeKeys = /* @__PURE__ */ new Map(), edgeKeys = /* @__PURE__ */ new Map();
  let numberIndex = 0;
  rows.forEach((row, r) => row.forEach((biome, c) => {
    const x = (c - (row.length - 1) / 2) * Math.sqrt(3) * 2.66, z = (r - (rows.length - 1) / 2) * 1.5 * 2.66;
    const tile = { id: tiles.length, biome, resource: terrainResource[biome], number: biome === "terra-seca" ? null : numbers[numberIndex++], x, z, nodes: [] };
    tiles.push(tile);
    for (let k = 0; k < 6; k++) {
      const angle = Math.PI / 6 + k * Math.PI / 3, nx = x + Math.cos(angle) * 2.66, nz = z + Math.sin(angle) * 2.66;
      const safeKey = `${Math.round(nx * 1e4)},${Math.round(nz * 1e4)}`;
      let id = nodeKeys.get(safeKey);
      if (id === void 0) {
        id = nodes.length;
        nodeKeys.set(safeKey, id);
        nodes.push({ id, x: nx, z: nz, tiles: [], edges: [] });
      }
      tile.nodes.push(id);
      nodes[id].tiles.push(tile.id);
    }
    for (let k = 0; k < 6; k++) {
      const a = tile.nodes[k], b = tile.nodes[(k + 1) % 6], key = [a, b].sort((a2, b2) => a2 - b2).join("-");
      if (!edgeKeys.has(key)) {
        const id = edges.length;
        edgeKeys.set(key, id);
        edges.push({ id, a, b });
        nodes[a].edges.push(id);
        nodes[b].edges.push(id);
      }
    }
  }));
  return { tiles, nodes, edges };
}
var map = makeMap();
var tradeStops = createTradeStops(map);
function accessibleStops(s, p) {
  return stopsFor(s).filter((stop) => stop.nodes.some((id) => s.buildings[id]?.owner === p));
}
function tradeRate(s, p, resource2) {
  const stops = accessibleStops(s, p);
  return stops.some((stop) => stop.resource === resource2) ? 2 : stops.some((stop) => stop.resource === null) ? 3 : 4;
}
var boardCache = /* @__PURE__ */ new Map();
var stopCache = /* @__PURE__ */ new WeakMap();
function stopsFor(s) {
  const board = boardFor(s);
  let stops = stopCache.get(board);
  if (!stops) {
    stops = createTradeStops(board);
    stopCache.set(board, stops);
  }
  return stops;
}
function boardFor(s) {
  if (s.boardSeed == null && s.mapSize !== "double") return map;
  const seed = s.boardSeed ?? 0, key = seed + ":" + (s.mapSize ?? "classic");
  if (boardCache.has(key)) return boardCache.get(key);
  let value = seed >>> 0;
  const random2 = () => {
    value = value + 1831565813 >>> 0;
    let t = value;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
  const shuffle = (items) => {
    for (let i = items.length - 1; i > 0; i--) {
      const j = Math.floor(random2() * (i + 1));
      [items[i], items[j]] = [items[j], items[i]];
    }
    return items;
  };
  const biomes = shuffle(Array.from({ length: s.mapSize === "double" ? 2 : 1 }, () => boardRows.flat()).flat()), numbers = shuffle(Array.from({ length: s.mapSize === "double" ? 2 : 1 }, () => map.tiles.flatMap((t) => t.number === null ? [] : [t.number])).flat());
  let offset = 0;
  const rows = rowLengths(s.mapSize).map((length) => {
    const result2 = biomes.slice(offset, offset + length);
    offset += length;
    return result2;
  });
  const result = makeMap(rows, numbers);
  if (boardCache.size >= 32) boardCache.delete(boardCache.keys().next().value);
  boardCache.set(key, result);
  return result;
}
var wallet = (n = 0) => ({ couro: n, lenha: n, barro: n, pedra: n, milho: n });
var playerNames = ["Voc\xEA", "Dona C\xEDcera", "Seu Z\xE9", "Dona L\xFAcia", "Seu Ant\xF4nio", "Dona Rosa"];
function newGame(boardSeed = Math.floor(Math.random() * 4294967296), options = {}) {
  const count = options.players ?? 3;
  if (!Number.isInteger(count) || count < 2 || count > 6) throw Error("Escolha de 2 a 6 jogadores.");
  const mapSize = options.mapSize ?? "classic";
  return { mapSize, development: createDevelopment(boardSeed ?? 0, count), boardSeed, version: 1, current: 0, round: 1, phase: "setup-house", setupStep: 0, lastNode: null, players: Array.from({ length: count }, () => ({ cards: wallet() })), bank: wallet(bankCapacity({ mapSize })), buildings: {}, roads: {}, robber: boardFor({ boardSeed, mapSize }).tiles.find((t) => !t.resource).id, dice: null, winner: null, log: ["Escolha o primeiro local da sua Casa de Taipa."] };
}
function points(s, p) {
  return Object.values(s.buildings).filter((b) => b.owner === p).reduce((n, b) => n + b.level, 0) + (s.development?.hands[p].filter((c) => developmentInfo[c.kind].prestige).length ?? 0) + (s.development?.armyOwner === p ? 2 : 0);
}
function publicPoints(s, p, viewer = 0) {
  return points(s, p) - (p !== viewer && s.phase !== "finished" ? s.development?.hands[p].filter((c) => developmentInfo[c.kind].prestige).length ?? 0 : 0);
}
function affordable(s, p, kind) {
  return resources.every((r) => s.players[p].cards[r] >= (costs[kind][r] ?? 0));
}
function legalHouses(s, p = s.current, setup = s.phase === "setup-house") {
  const map2 = boardFor(s);
  if (Object.values(s.buildings).filter((b) => b.owner === p && b.level === 1).length >= 5) return [];
  return map2.nodes.filter((n) => !s.buildings[n.id] && n.edges.every((id) => !s.buildings[otherEnd(id, n.id, map2)]) && (setup || n.edges.some((id) => s.roads[id] === p))).map((n) => n.id);
}
function otherEnd(edge, node, board = map) {
  const e = board.edges[edge];
  return e.a === node ? e.b : e.a;
}
function legalRoads(s, p = s.current) {
  const map2 = boardFor(s);
  if (Object.values(s.roads).filter((owner) => owner === p).length >= 15) return [];
  return map2.edges.filter((e) => s.roads[e.id] === void 0 && (s.phase === "setup-road" ? e.a === s.lastNode || e.b === s.lastNode : [e.a, e.b].some((id) => s.buildings[id] ? s.buildings[id].owner === p : map2.nodes[id].edges.some((edge) => s.roads[edge] === p)))).map((e) => e.id);
}
function legalCities(s, p = s.current) {
  return Object.values(s.buildings).filter((b) => b.owner === p && b.level === 2).length >= 4 ? [] : Object.entries(s.buildings).filter(([, b]) => b.owner === p && b.level === 1).map(([id]) => Number(id));
}
function note(s, message) {
  s.log.push(message);
  if (s.log.length > 50) s.log.shift();
}
function checkPlayer(s, p) {
  if (s.winner !== null) throw new Error("A partida j\xE1 terminou.");
  if (s.current !== p) throw new Error("Espere a sua vez.");
}
function pay(s, p, kind) {
  if (!affordable(s, p, kind)) throw new Error("Voc\xEA ainda n\xE3o tem os recursos necess\xE1rios.");
  for (const r of resources) {
    const n = costs[kind][r] ?? 0;
    s.players[p].cards[r] -= n;
    s.bank[r] += n;
  }
}
function victory(s, p) {
  if (points(s, p) >= TARGET) {
    s.winner = p;
    s.phase = "finished";
    if (s.development) {
      s.development.freeRoads = null;
      s.development.robberReturn = null;
    }
    note(s, `${playerNames[p]} venceu com ${points(s, p)} pontos!`);
  }
}
function give(s, p, r, n) {
  const amount = Math.min(n, s.bank[r]);
  s.bank[r] -= amount;
  s.players[p].cards[r] += amount;
}
function build(s, p, kind, id) {
  const map2 = boardFor(s);
  checkPlayer(s, p);
  const setup = s.phase === "setup-house" || s.phase === "setup-road", free = s.phase === "free-roads" && kind === "road" && s.development?.freeRoads?.owner === p;
  if (setup && kind !== (s.phase === "setup-house" ? "settlement" : "road")) throw new Error("Conclua a constru\xE7\xE3o inicial indicada.");
  if (!setup && !free && s.phase !== "build") throw new Error("Role os dados antes de construir.");
  const legal = kind === "road" ? legalRoads(s, p) : kind === "city" ? legalCities(s, p) : legalHouses(s, p, setup);
  if (!legal.includes(id)) throw new Error("Este local n\xE3o est\xE1 dispon\xEDvel para essa constru\xE7\xE3o.");
  if (!setup && !free) pay(s, p, kind);
  if (kind === "road") {
    s.roads[id] = p;
    note(s, `${playerNames[p]} construiu uma estrada${free ? " com o Mutir\xE3o" : ""}.`);
    if (free) {
      const pending = s.development.freeRoads;
      pending.left--;
      if (!pending.left || !legalRoads(s, p).length) {
        s.phase = pending.returnPhase;
        s.development.freeRoads = null;
      }
    }
    if (setup) {
      s.setupStep++;
      s.lastNode = null;
      if (s.setupStep === setupFor(s).length) {
        s.current = 0;
        s.phase = "roll";
        note(s, "Tudo pronto! Role os dados para come\xE7ar.");
      } else {
        s.current = setupFor(s)[s.setupStep];
        s.phase = "setup-house";
      }
    }
  } else {
    s.buildings[id] = { owner: p, level: kind === "city" ? 2 : 1 };
    note(s, `${playerNames[p]} construiu ${kind === "city" ? "uma Vila Sertaneja" : "uma Casa de Taipa"}.`);
    if (setup) {
      s.lastNode = id;
      s.phase = "setup-road";
      if (s.setupStep >= s.players.length) for (const tid of map2.nodes[id].tiles) {
        const r = boardFor(s).tiles[tid].resource;
        if (r) give(s, p, r, 1);
      }
    }
  }
  if (!setup) victory(s, p);
}
function rollDice(s, p, random2 = Math.random) {
  checkPlayer(s, p);
  if (s.phase !== "roll") throw new Error("Os dados j\xE1 foram rolados neste turno.");
  const die = () => Math.min(6, Math.max(1, Math.floor(random2() * 6) + 1));
  s.dice = [die(), die()];
  const sum = s.dice[0] + s.dice[1];
  note(s, `${playerNames[p]} tirou ${s.dice.join(" + ")} = ${sum}.`);
  if (sum === 7) {
    for (let owner = 0; owner < s.players.length; owner++) {
      const cards = s.players[owner].cards, total = resources.reduce((n, r) => n + cards[r], 0);
      if (total <= 7) continue;
      let remaining = Math.floor(total / 2);
      const count = remaining;
      while (remaining--) {
        const r = resources.reduce((a, b) => cards[a] >= cards[b] ? a : b);
        cards[r]--;
        s.bank[r]++;
      }
      note(s, `${playerNames[owner]} devolveu ${count} recursos ao banco (limite de 7).`);
    }
    s.phase = "robber";
    note(s, "Mova o Cobrador do Coronel para outro terreno. Ele ficar\xE1 sem produzir.");
    return sum;
  }
  const demand = resources.reduce((out, r) => (out[r] = [], out), {});
  for (const t of boardFor(s).tiles) {
    if (t.number !== sum || !t.resource || t.id === s.robber) continue;
    for (const node of t.nodes) {
      const b = s.buildings[node];
      if (b) demand[t.resource].push({ owner: b.owner, amount: b.level });
    }
  }
  const received = [0, 0, 0];
  for (const r of resources) {
    const total = demand[r].reduce((n, a) => n + a.amount, 0);
    if (total > s.bank[r]) {
      note(s, `O banco ficou sem ${names[r]}; esta produ\xE7\xE3o n\xE3o foi distribu\xEDda.`);
      continue;
    }
    for (const a of demand[r]) {
      give(s, a.owner, r, a.amount);
      received[a.owner] += a.amount;
    }
  }
  if (!received.some(Boolean)) note(s, "Nenhuma constru\xE7\xE3o recebeu recursos nesta rodada.");
  else note(s, received.map((n, i) => n ? `${playerNames[i]}: +${n}` : "").filter(Boolean).join(" \xB7 "));
  s.phase = "build";
  return sum;
}
function moveRobber(s, p, tile, random2 = Math.random) {
  const map2 = boardFor(s);
  checkPlayer(s, p);
  if (s.phase !== "robber") throw new Error("N\xE3o \xE9 hora de mover o Cobrador.");
  if (!map2.tiles[tile] || tile === s.robber) throw new Error("Escolha outro terreno.");
  s.robber = tile;
  const victims = [...new Set(map2.tiles[tile].nodes.map((id) => s.buildings[id]?.owner).filter((owner) => owner !== void 0 && owner !== p))].filter((owner) => resources.some((r) => s.players[owner].cards[r] > 0));
  if (victims.length) {
    const victim = victims[Math.min(victims.length - 1, Math.floor(random2() * victims.length))], cards = s.players[victim].cards, total = resources.reduce((n, r) => n + cards[r], 0);
    let index = Math.floor(random2() * total);
    for (const r of resources) {
      index -= cards[r];
      if (index < 0) {
        cards[r]--;
        s.players[p].cards[r]++;
        note(s, `${playerNames[p]} recebeu 1 ${names[r]} de ${playerNames[victim]}.`);
        break;
      }
    }
  }
  s.phase = s.development?.robberReturn ?? "build";
  if (s.development) s.development.robberReturn = null;
  note(s, `O Cobrador bloqueou o terreno ${tile + 1}.`);
}
function trade(s, p, from, to, amount = 1) {
  checkPlayer(s, p);
  if (s.phase !== "build") throw new Error("Role os dados antes de trocar.");
  if (!resources.includes(from) || !resources.includes(to) || from === to) throw new Error("Escolha dois recursos diferentes.");
  if (!Number.isInteger(amount) || amount < 1 || amount > bankCapacity(s)) throw new Error("Escolha uma quantidade inteira de 1 a 19.");
  const rate = tradeRate(s, p, from), required = rate * amount;
  if (s.players[p].cards[from] < required) throw new Error(`Voc\xEA precisa de ${required} cartas iguais para trocar.`);
  if (s.bank[to] < amount) throw new Error("O banco n\xE3o tem a quantidade solicitada.");
  s.players[p].cards[from] -= required;
  s.bank[from] += required;
  s.bank[to] -= amount;
  s.players[p].cards[to] += amount;
  note(s, `${playerNames[p]} trocou ${required} ${names[from]} por ${amount} ${names[to]}.`);
}
function tradeBundle(value) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((r) => !resources.includes(r))) throw new Error("Use apenas os cinco recursos do jogo.");
  const entries = resources.map((r) => [r, value[r] ?? 0]);
  if (entries.some(([, n]) => typeof n !== "number" || !Number.isInteger(n) || n < 0 || n > 38)) throw new Error("Use quantidades inteiras de 0 a 19 para os cinco recursos.");
  return Object.fromEntries(entries);
}
function tradeWalletValue(s, p, cards) {
  const goals = [];
  if (legalCities(s, p).length) goals.push("city");
  if (legalHouses(s, p, false).length) goals.push("settlement");
  if (legalRoads(s, p).length) goals.push("road");
  const progress = goals.reduce((best, kind) => {
    const ingredients = Object.entries(costs[kind]), total = ingredients.reduce((n, [, q]) => n + q, 0), filled = ingredients.reduce((n, [r, q]) => n + Math.min(cards[r], q), 0), complete = filled === total;
    return Math.max(best, { city: 2.2, settlement: 2, road: 0.7 }[kind] * (filled / total + (complete ? 0.8 : 0)));
  }, 0);
  return resources.reduce((n, r) => n + 1.8 * Math.sqrt(cards[r]), 0) + progress;
}
function proposePlayerTrade(s, p, partner, offer, request) {
  checkPlayer(s, p);
  if (s.phase !== "build") throw new Error("Role os dados antes de negociar com os jogadores.");
  if (!Number.isInteger(partner) || partner === p || partner < 0 || partner >= s.players.length) throw new Error("Escolha outro jogador para negociar.");
  const give2 = tradeBundle(offer), take = tradeBundle(request), total = (cards) => resources.reduce((n, r) => n + cards[r], 0);
  if (!total(give2) || !total(take)) throw new Error("Escolha ao menos um recurso para oferecer e um para receber.");
  if (resources.some((r) => give2[r] && take[r])) throw new Error("N\xE3o ofere\xE7a e pe\xE7a o mesmo recurso na mesma proposta.");
  if (resources.some((r) => s.players[p].cards[r] < give2[r])) throw new Error("Voc\xEA n\xE3o tem todos os recursos que est\xE1 oferecendo.");
  const reject = (message) => {
    note(s, `${playerNames[partner]} recusou a proposta de ${playerNames[p]}.`);
    return { accepted: false, message: `${playerNames[partner]} recusou: ${message}` };
  };
  if (resources.some((r) => s.players[partner].cards[r] < take[r])) return reject("N\xE3o tenho todos os recursos que voc\xEA pediu.");
  const other = s.players[partner].cards, after = Object.fromEntries(resources.map((r) => [r, other[r] + give2[r] - take[r]]));
  if (tradeWalletValue(s, partner, after) + 1e-6 < tradeWalletValue(s, partner, other)) return reject("Prefiro guardar esses recursos para minhas constru\xE7\xF5es. Tente oferecer mais ou pedir menos.");
  for (const r of resources) {
    s.players[p].cards[r] += take[r] - give2[r];
    other[r] += give2[r] - take[r];
  }
  const describe = (bundle) => resources.filter((r) => bundle[r] > 0).map((r) => `${bundle[r]} ${names[r]}`).join(" + ");
  note(s, `${playerNames[p]} negociou com ${playerNames[partner]}: ${describe(give2)} por ${describe(take)}.`);
  return { accepted: true, message: `${playerNames[partner]} aceitou! Voc\xEA entregou ${describe(give2)} e recebeu ${describe(take)}.` };
}
function developmentHand(s, p) {
  return s.development?.hands[p] ?? [];
}
function canBuyDevelopment(s, p = s.current) {
  return s.current === p && s.phase === "build" && s.winner === null && (s.development?.deck.length ?? 25) > 0 && Object.entries(developmentCost).every(([r, n]) => s.players[p].cards[r] >= n);
}
function buyDevelopment(s, p) {
  checkPlayer(s, p);
  if (s.phase !== "build") throw new Error("Role os dados antes de comprar cartas.");
  const d = s.development ?? createDevelopment(s.boardSeed ?? 0, s.players.length);
  if (!d.deck.length) throw new Error("As cartas de desenvolvimento acabaram.");
  if (!Object.entries(developmentCost).every(([r, n]) => s.players[p].cards[r] >= n)) throw new Error("A carta custa 1 Couro + 1 Pedra + 1 Milho.");
  const id = 25 - d.deck.length, kind = d.deck.pop();
  s.development = d;
  for (const [r, n] of Object.entries(developmentCost)) {
    s.players[p].cards[r] -= n;
    s.bank[r] += n;
  }
  const card = { id, kind, boughtTurn: developmentTurn(s) };
  d.hands[p].push(card);
  note(s, `${playerNames[p]} comprou uma carta do Sert\xE3o.`);
  victory(s, p);
  return card;
}
function usedDevelopmentThisTurn(s) {
  return s.development?.discard.some((c) => c.playedTurn === developmentTurn(s)) ?? false;
}
function canPlayDevelopment(s, p, id) {
  const card = developmentHand(s, p).find((c) => c.id === id);
  if (!card || developmentInfo[card.kind].prestige || s.current !== p || s.winner !== null || !["roll", "build"].includes(s.phase) || card.boughtTurn >= developmentTurn(s) || usedDevelopmentThisTurn(s)) return false;
  if (card.kind === "roads") return legalRoads(s, p).length > 0;
  if (card.kind === "plenty") return resources.some((r) => s.bank[r] > 0);
  return true;
}
function knightCount(s, p) {
  return s.development?.discard.filter((c) => c.kind === "knight" && c.owner === p).length ?? 0;
}
function updateArmy(s) {
  const d = s.development;
  const counts = s.players.map((_, p) => knightCount(s, p)), max = Math.max(...counts), old = d.armyOwner;
  if (max < 3) d.armyOwner = null;
  else if (old === null || counts[old] !== max) {
    const candidates = s.players.map((_, i) => i).filter((p) => counts[p] === max);
    d.armyOwner = candidates.length === 1 ? candidates[0] : null;
  }
  if (d.armyOwner !== old && d.armyOwner !== null) note(s, `${playerNames[d.armyOwner]} conquistou o Maior Grupo de Cangaceiros: +2 pontos.`);
}
function playDevelopment(s, p, id, choice) {
  checkPlayer(s, p);
  if (!canPlayDevelopment(s, p, id)) throw new Error("Use apenas uma carta de a\xE7\xE3o por turno, a partir do turno seguinte \xE0 compra.");
  const d = s.development, card = d.hands[p].find((c) => c.id === id), returnPhase = s.phase;
  let selected = [];
  if (card.kind === "monopoly") {
    if (!resources.includes(choice)) throw new Error("Escolha o recurso do Acordo.");
    selected = [choice];
  }
  if (card.kind === "plenty") {
    const needed = Math.min(2, resources.reduce((n, r) => n + s.bank[r], 0));
    if (!Array.isArray(choice) || choice.length !== needed || choice.some((r) => !resources.includes(r))) throw new Error(`Escolha ${needed} recurso(s) para a Safra.`);
    selected = choice;
    for (const r of resources) if (selected.filter((v) => v === r).length > s.bank[r]) throw new Error("O banco n\xE3o tem os recursos escolhidos.");
  }
  d.hands[p] = d.hands[p].filter((c) => c.id !== id);
  d.discard.push({ ...card, owner: p, playedTurn: developmentTurn(s) });
  note(s, `${playerNames[p]} usou ${developmentInfo[card.kind].title}.`);
  if (card.kind === "knight") {
    d.robberReturn = returnPhase;
    s.phase = "robber";
    updateArmy(s);
  }
  if (card.kind === "roads") {
    d.freeRoads = { owner: p, left: 2, returnPhase };
    s.phase = "free-roads";
  }
  if (card.kind === "plenty") for (const r of selected) give(s, p, r, 1);
  if (card.kind === "monopoly") {
    const r = selected[0];
    let amount = 0;
    for (let owner = 0; owner < s.players.length; owner++) if (owner !== p) {
      amount += s.players[owner].cards[r];
      s.players[owner].cards[r] = 0;
    }
    s.players[p].cards[r] += amount;
    note(s, `${playerNames[p]} recebeu ${amount} ${names[r]} pelo Acordo.`);
  }
  victory(s, p);
}
function finishFreeRoads(s, p) {
  checkPlayer(s, p);
  const pending = s.development?.freeRoads;
  if (s.phase !== "free-roads" || !pending || pending.owner !== p || pending.left === 2) throw new Error("Coloque pelo menos uma estrada do Mutir\xE3o.");
  s.phase = pending.returnPhase;
  s.development.freeRoads = null;
}
function endTurn(s, p) {
  checkPlayer(s, p);
  if (s.phase !== "build") throw new Error("Conclua a a\xE7\xE3o indicada antes de terminar o turno.");
  victory(s, p);
  if (s.winner !== null) return;
  s.current = (p + 1) % s.players.length;
  if (s.current === 0) s.round++;
  s.phase = "roll";
  s.dice = null;
  note(s, `Vez de ${playerNames[s.current]}.`);
}
function scoreNode(id, board = map) {
  return board.nodes[id].tiles.reduce((n, tid) => {
    const t = board.tiles[tid];
    return n + (t.number ? 6 - Math.abs(7 - t.number) : 0);
  }, 0) + new Set(board.nodes[id].tiles.map((t) => board.tiles[t].resource).filter(Boolean)).size * 1.2;
}
function chooseRoad(s, p) {
  const map2 = boardFor(s);
  const targets = map2.nodes.filter((n) => !s.buildings[n.id] && n.edges.every((id) => !s.buildings[otherEnd(id, n.id, map2)]));
  const distance = (node) => targets.reduce((best, t) => Math.min(best, Math.hypot(t.x - map2.nodes[node].x, t.z - map2.nodes[node].z) - scoreNode(t.id, boardFor(s)) * 0.05), 99);
  return legalRoads(s, p).sort((a, b) => Math.min(distance(map2.edges[a].a), distance(map2.edges[a].b)) - Math.min(distance(map2.edges[b].a), distance(map2.edges[b].b)))[0];
}
function botDevelopment(s, p) {
  if (s.phase !== "build") return false;
  const ready = developmentHand(s, p).filter((c) => canPlayDevelopment(s, p, c.id));
  const monopoly = ready.find((c) => c.kind === "monopoly");
  if (monopoly) {
    const r = resources.reduce((a, b) => s.players.reduce((n, v, i) => n + (i !== p ? v.cards[b] : 0), 0) > s.players.reduce((n, v, i) => n + (i !== p ? v.cards[a] : 0), 0) ? b : a);
    if (s.players.some((v, i) => i !== p && v.cards[r] > 0)) {
      playDevelopment(s, p, monopoly.id, r);
      return true;
    }
  }
  const plenty = ready.find((c) => c.kind === "plenty");
  if (plenty) {
    const bank = { ...s.bank }, cards = { ...s.players[p].cards }, choices = [];
    const goals = [["city", legalCities(s, p)], ["settlement", legalHouses(s, p, false)], ["road", legalRoads(s, p)]].filter(([, ids]) => ids.length);
    for (let i = 0; i < Math.min(2, resources.reduce((n, r) => n + s.bank[r], 0)); i++) {
      const r = goals.flatMap(([kind]) => resources.filter((r2) => cards[r2] < (costs[kind][r2] ?? 0) && bank[r2] > 0))[0] ?? resources.filter((r2) => bank[r2] > 0).sort((a, b) => cards[a] - cards[b])[0];
      choices.push(r);
      bank[r]--;
      cards[r]++;
    }
    playDevelopment(s, p, plenty.id, choices);
    return true;
  }
  const roads = ready.find((c) => c.kind === "roads");
  if (roads) {
    playDevelopment(s, p, roads.id);
    return true;
  }
  const knight = ready.find((c) => c.kind === "knight");
  if (knight) {
    playDevelopment(s, p, knight.id);
    return true;
  }
  return false;
}
function botStep(s, random2 = Math.random) {
  const p = s.current;
  if (s.phase === "finished") return;
  if (s.phase === "setup-house") {
    const ids = legalHouses(s, p, true).sort((a, b) => scoreNode(b, boardFor(s)) - scoreNode(a, boardFor(s)));
    if (!ids.length) throw new Error("Sem espa\xE7o para a prepara\xE7\xE3o.");
    build(s, p, "settlement", ids[0]);
    return;
  }
  if (s.phase === "setup-road") {
    const id = chooseRoad(s, p);
    if (id === void 0) throw new Error("Sem estrada inicial dispon\xEDvel.");
    build(s, p, "road", id);
    return;
  }
  if (s.phase === "roll") {
    rollDice(s, p, random2);
    return;
  }
  if (s.phase === "robber") {
    const tile = boardFor(s).tiles.filter((t) => t.id !== s.robber).sort((a, b) => {
      const score = (t) => t.nodes.reduce((n, id) => {
        const v = s.buildings[id];
        return n + (v ? (v.owner === p ? -3 : 1) * v.level : 0);
      }, 0) * (t.number ? 6 - Math.abs(7 - t.number) : 0);
      return score(b) - score(a);
    })[0];
    moveRobber(s, p, tile.id, random2);
    return;
  }
  if (s.phase === "free-roads") {
    const id = chooseRoad(s, p);
    if (id !== void 0) build(s, p, "road", id);
    else finishFreeRoads(s, p);
    return;
  }
  if (botDevelopment(s, p)) return;
  const options = [{ kind: "city", ids: legalCities(s, p) }, { kind: "settlement", ids: legalHouses(s, p, false) }, { kind: "road", ids: legalRoads(s, p) }];
  for (const option of options) {
    if (option.ids.length && affordable(s, p, option.kind)) {
      const id = option.kind === "road" ? chooseRoad(s, p) : option.ids.sort((a, b) => scoreNode(b, boardFor(s)) - scoreNode(a, boardFor(s)))[0];
      build(s, p, option.kind, id);
      return;
    }
  }
  if (canBuyDevelopment(s, p)) {
    buyDevelopment(s, p);
    return;
  }
  for (const option of options) {
    if (!option.ids.length) continue;
    const cost = costs[option.kind];
    const need = resources.find((r) => s.players[p].cards[r] < (cost[r] ?? 0) && s.bank[r] > 0);
    if (!need) continue;
    const surplus = resources.filter((r) => r !== need && s.players[p].cards[r] - (cost[r] ?? 0) >= tradeRate(s, p, r)).sort((a, b) => s.players[p].cards[b] - s.players[p].cards[a])[0];
    if (surplus) {
      trade(s, p, surplus, need);
      return;
    }
  }
  endTurn(s, p);
}
function validSave(value) {
  try {
    const s = value;
    const map2 = boardFor(s ?? {});
    if (!s || s.version !== 1 || !Number.isInteger(s.current) || s.current < 0 || s.current >= s.players.length || !["setup-house", "setup-road", "roll", "build", "robber", "finished", "free-roads"].includes(s.phase) || !Array.isArray(s.players) || (s.players.length < 2 || s.players.length > 6) || !Array.isArray(s.log) || s.log.some((x) => typeof x !== "string") || !Number.isInteger(s.round) || s.round < 1 || !Number.isInteger(s.setupStep) || s.setupStep < 0 || s.setupStep > s.players.length * 2 || !map2.tiles[s.robber] || !(s.winner === null || Number.isInteger(s.winner) && s.winner >= 0 && s.winner < s.players.length) || !s.buildings || !s.roads) return false;
    if (s.mapSize !== void 0 && !["classic", "double"].includes(s.mapSize)) return false;
    if (!validateDevelopment(s.development, developmentTurn(s), s.current, s.phase, s.players.length)) return false;
    if (s.boardSeed != null && (!Number.isInteger(s.boardSeed) || s.boardSeed < 0 || s.boardSeed > 4294967295)) return false;
    if (s.phase.startsWith("setup") && (s.setupStep >= s.players.length * 2 || s.current !== setupFor(s)[s.setupStep])) return false;
    if (s.phase === "setup-road" && (s.lastNode === null || s.buildings[s.lastNode]?.owner !== s.current)) return false;
    if (s.phase === "finished" && (s.winner === null || points(s, s.winner) < TARGET)) return false;
    if (s.phase !== "finished" && s.winner !== null) return false;
    if (s.dice !== null && (!Array.isArray(s.dice) || s.dice.length !== 2 || s.dice.some((n) => !Number.isInteger(n) || n < 1 || n > 6))) return false;
    for (const r of resources) {
      const counts = [s.bank[r], ...s.players.map((p) => p.cards[r])];
      if (counts.some((n) => !Number.isInteger(n) || n < 0) || counts.reduce((a, b) => a + b, 0) !== bankCapacity(s)) return false;
    }
    for (const [id, b] of Object.entries(s.buildings)) {
      if (!map2.nodes[Number(id)] || !b || (!Number.isInteger(b.owner) || b.owner < 0 || b.owner >= s.players.length) || ![1, 2].includes(b.level)) return false;
    }
    for (const [id, owner] of Object.entries(s.roads)) if (!map2.edges[Number(id)] || (!Number.isInteger(owner) || owner < 0 || owner >= s.players.length)) return false;
    return true;
  } catch {
    return false;
  }
}

// server/room.ts
var token = () => randomBytes(24).toString("hex");
var random = () => randomInt(16777216) / 16777216;
var wallet2 = (v) => !!v && typeof v === "object" && resources.every((r) => Number.isInteger(v[r]) && v[r] >= 0 && v[r] <= 38) && Object.keys(v).length === 5;
var resource = (v) => resources.includes(v);
function parseCommand(v) {
  if (!v || typeof v !== "object") throw Error("Jogada inv\xE1lida.");
  const a = v, id = Number.isInteger(a.id) && Number(a.id) >= 0 && Number(a.id) < 300;
  switch (a.kind) {
    case "roll":
    case "end":
    case "buy":
    case "finish":
      break;
    case "build":
      if (!id || !["road", "settlement", "city"].includes(String(a.build))) throw Error("Constru\xE7\xE3o inv\xE1lida.");
      break;
    case "robber":
      if (!id || Number(a.id) > 37) throw Error("Terreno inv\xE1lido.");
      break;
    case "bank":
      if (!resource(a.from) || !resource(a.to) || !Number.isInteger(a.amount) || Number(a.amount) < 1 || Number(a.amount) > 38) throw Error("Troca inv\xE1lida.");
      break;
    case "play":
      if (!id || Number(a.id) > 24 || !(a.choice === void 0 || resource(a.choice) || Array.isArray(a.choice) && a.choice.length >= 1 && a.choice.length <= 2 && a.choice.every(resource))) throw Error("Carta inv\xE1lida.");
      break;
    case "offer":
      if (!Number.isInteger(a.to) || Number(a.to) < 0 || Number(a.to) > 5 || !wallet2(a.give) || !wallet2(a.take)) throw Error("Proposta inv\xE1lida.");
      break;
    case "reply":
      if (typeof a.offerId !== "string" || a.offerId.length > 60 || typeof a.accept !== "boolean") throw Error("Resposta inv\xE1lida.");
      break;
    default:
      throw Error("Jogada desconhecida.");
  }
  return a;
}
var Room = class _Room {
  constructor(code, now = () => Date.now(), options = {}) {
    this.code = code;
    this.now = now;
    const count = options?.players ?? 3, mapSize = options?.mapSize ?? "classic";
    if (!Number.isInteger(count) || count < 2 || count > 6 || !["classic", "double"].includes(mapSize)) throw Error("Escolha de 2 a 6 jogadores e um mapa v\xE1lido.");
    this.options = { players: count, mapSize };
    this.members = Array.from({ length: count }, () => null);
  }
  code;
  now;
  members;
  options;
  host = 0;
  state = null;
  version = 0;
  event = null;
  offer = null;
  busyUntil = 0;
  updatedAt = Date.now();
  requests = /* @__PURE__ */ new Map();
  join(name) {
    if (this.state) throw Error("Esta partida j\xE1 come\xE7ou.");
    const seat = this.members.findIndex((m) => !m);
    if (seat < 0) throw Error("A sala est\xE1 cheia.");
    const member = { name: cleanName(name), token: token(), lastSeen: this.now() };
    this.members[seat] = member;
    if (this.host < 0) this.host = seat;
    this.changed();
    return { seat, token: member.token };
  }
  authenticate(secret) {
    if (typeof secret !== "string" || secret.length !== 48) throw Error("Entre na sala novamente.");
    const seat = this.members.findIndex((m) => m?.token === secret);
    if (seat < 0) throw Error("Sua sess\xE3o n\xE3o foi encontrada.");
    this.members[seat].lastSeen = this.now();
    return seat;
  }
  start(p) {
    if (p !== this.host) throw Error("Somente quem criou a sala pode come\xE7ar.");
    if (this.state) throw Error("A partida j\xE1 come\xE7ou.");
    if (this.members.filter(Boolean).length < 2) throw Error("Aguarde pelo menos mais um jogador.");
    this.state = newGame(randomInt(4294967296), this.options);
    this.state.development = createDevelopment(0, this.members.length);
    const deck = this.state.development.deck;
    for (let i = deck.length - 1; i > 0; i--) {
      const j = randomInt(i + 1);
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    this.changed("start");
  }
  leave(p) {
    if (this.state) {
      this.members[p].lastSeen = 0;
      this.changed();
      return;
    }
    this.members[p] = null;
    if (this.host === p) this.host = this.members.findIndex(Boolean);
    this.changed();
  }
  changed(kind, build2) {
    this.version++;
    this.updatedAt = this.now();
    if (kind) this.event = { id: this.version, at: this.now(), kind, build: build2, dice: kind === "roll" ? this.state.dice : void 0 };
  }
  command(p, command, version, requestId) {
    if (typeof requestId !== "string" || !/^[\w-]{8,80}$/.test(requestId)) throw Error("Identificador de jogada inv\xE1lido.");
    const secret = this.members[p].token, seen = this.requests.get(secret) ?? /* @__PURE__ */ new Set();
    if (seen.has(requestId)) return;
    const a = parseCommand(command), s = this.state;
    if (!s) throw Error("Aguarde o in\xEDcio da partida.");
    if (version !== this.version) throw Error("O tabuleiro mudou. Tente novamente.");
    if (this.now() < this.busyUntil) throw Error("Aguarde a anima\xE7\xE3o da jogada.");
    if (s.winner !== null) throw Error("A partida terminou.");
    const next = structuredClone(s);
    let event = "action", kind;
    if (a.kind === "reply") {
      const o = this.offer;
      if (!o || o.id !== a.offerId || o.to !== p || o.expires < this.now() || s.current !== o.from || s.phase !== "build") throw Error("Esta proposta n\xE3o est\xE1 mais dispon\xEDvel.");
      if (a.accept) {
        this.transfer(next, o);
        next.log.push("Troca entre jogadores conclu\xEDda.");
      } else next.log.push("A proposta de troca foi recusada.");
      this.offer = null;
    } else {
      if (s.current !== p) throw Error("Aguarde a sua vez.");
      switch (a.kind) {
        case "build":
          build(next, p, a.build, a.id);
          event = "build";
          kind = a.build;
          break;
        case "roll":
          rollDice(next, p, random);
          event = "roll";
          break;
        case "robber":
          moveRobber(next, p, a.id, random);
          break;
        case "end":
          endTurn(next, p);
          this.offer = null;
          break;
        case "bank":
          trade(next, p, a.from, a.to, a.amount);
          break;
        case "buy":
          buyDevelopment(next, p);
          break;
        case "play":
          playDevelopment(next, p, a.id, a.choice);
          break;
        case "finish":
          finishFreeRoads(next, p);
          break;
        case "offer": {
          if (s.phase !== "build" || a.to === p) throw Error("Voc\xEA s\xF3 pode negociar com outro jogador ap\xF3s os dados.");
          this.validateOffer(next, p, a.to, a.give, a.take);
          if (!this.members[a.to]) {
            const result = proposePlayerTrade(next, p, a.to, a.give, a.take);
            if (!result.accepted) next.log.push("O Tropeiro recusou a proposta.");
          } else {
            this.offer = { id: token(), from: p, to: a.to, give: { ...a.give }, take: { ...a.take }, expires: this.now() + 9e4 };
          }
          break;
        }
      }
    }
    next.log = next.log.slice(-50);
    if (!validSave(next)) throw Error("N\xE3o foi poss\xEDvel validar a jogada.");
    this.state = next;
    this.changed(event, kind);
    if (event === "roll") this.busyUntil = this.now() + 6500;
    if (event === "build") this.busyUntil = this.now() + 3500;
    seen.add(requestId);
    if (seen.size > 64) seen.delete(seen.values().next().value);
    this.requests.set(secret, seen);
  }
  validateOffer(s, from, to, give2, take) {
    if (!resources.some((r) => give2[r]) || !resources.some((r) => take[r]) || resources.some((r) => give2[r] && take[r] || give2[r] > s.players[from].cards[r] || take[r] > s.players[to].cards[r])) throw Error("A proposta precisa de recursos dispon\xEDveis dos dois lados.");
  }
  transfer(s, o) {
    this.validateOffer(s, o.from, o.to, o.give, o.take);
    for (const r of resources) {
      s.players[o.from].cards[r] += o.take[r] - o.give[r];
      s.players[o.to].cards[r] += o.give[r] - o.take[r];
    }
  }
  tick() {
    if (!this.state || this.state.winner !== null || this.members[this.state.current] || this.now() < this.busyUntil) return;
    const before = this.state, next = structuredClone(before);
    botStep(next, random);
    const built = Object.keys(next.roads).length > Object.keys(before.roads).length ? "road" : Object.entries(next.buildings).find(([id, b]) => !before.buildings[+id] || b.level > before.buildings[+id].level)?.[1].level === 2 ? "city" : Object.keys(next.buildings).length > Object.keys(before.buildings).length ? "settlement" : void 0;
    const kind = before.phase === "roll" ? "roll" : built ? "build" : "action";
    this.state = next;
    this.offer = null;
    this.changed(kind, built);
    this.busyUntil = this.now() + (kind === "roll" ? 6500 : kind === "build" ? 3500 : 700);
  }
  view(p) {
    const order = Array.from({ length: this.members.length }, (_, i) => (p + i) % this.members.length), index = (n) => order.indexOf(n), s = this.state ? structuredClone(this.state) : null;
    const totals = order.map((i) => this.state ? resources.reduce((n, r) => n + this.state.players[i].cards[r], 0) : 0), handCounts = order.map((i) => this.state?.development?.hands[i].length ?? 0), scores = order.map((i) => this.state ? publicPoints(this.state, i, p) : 0);
    if (s) {
      const labels = playerNames;
      s.log = s.log.map((line) => line.replace(new RegExp(labels.join("|"), "g"), (v) => this.members[labels.indexOf(v)]?.name ?? (labels.indexOf(v) === 0 ? "Seu Chico" : v)));
      s.onlineTurn = (s.round - 1) * s.players.length + s.current;
      s.current = index(s.current);
      s.winner = s.winner === null ? null : index(s.winner);
      s.players = order.map((i) => i === p ? s.players[i] : { cards: { couro: 0, lenha: 0, barro: 0, pedra: 0, milho: 0 } });
      for (const b of Object.values(s.buildings)) b.owner = index(b.owner);
      for (const id of Object.keys(s.roads)) s.roads[+id] = index(s.roads[+id]);
      if (s.development) {
        const d = s.development;
        d.hands = order.map((i) => i === p || s.phase === "finished" ? d.hands[i] : []);
        d.deck = d.deck.map(() => "knight");
        d.discard.forEach((c) => c.owner = index(c.owner));
        if (d.armyOwner !== null) d.armyOwner = index(d.armyOwner);
        if (d.freeRoads) d.freeRoads.owner = index(d.freeRoads.owner);
      }
    }
    const offer = this.offer && (this.offer.to === p || this.offer.from === p) && this.offer.expires >= this.now() ? { ...this.offer, from: index(this.offer.from), to: index(this.offer.to) } : null;
    return { code: this.code, options: this.options, version: this.version, seat: p, host: this.host === p, started: !!s, members: order.map((i) => ({ name: this.members[i]?.name ?? (i === 0 ? "Seu Chico" : playerNames[i]), connected: !!this.members[i] && this.now() - this.members[i].lastSeen < 2e4, bot: !this.members[i] })), state: s, totals, handCounts, scores, offer, event: this.event, busyUntil: this.busyUntil, serverTime: this.now() };
  }
  dump() {
    return { code: this.code, options: this.options, members: this.members, host: this.host, state: this.state, version: this.version, event: this.event, offer: this.offer, busyUntil: this.busyUntil, updatedAt: this.updatedAt };
  }
  static restore(v) {
    if (!/^[A-Z2-9]{6}$/.test(v.code) || v.state && !validSave(v.state)) throw Error("Sala salva inv\xE1lida.");
    const r = new _Room(v.code, () => Date.now(), v.options ?? { players: v.members.length, mapSize: v.state?.mapSize ?? "classic" });
    Object.assign(r, v);
    r.members.forEach((m) => {
      if (m) m.lastSeen = 0;
    });
    return r;
  }
};
function cleanName(v) {
  if (typeof v !== "string") throw Error("Digite seu nome.");
  const name = v.replace(/[<>\x00-\x1f]/g, "").trim().slice(0, 24);
  if (name.length < 2) throw Error("Use um nome com pelo menos 2 letras.");
  return name;
}

// server/index.ts
var rooms = /* @__PURE__ */ new Map();
var limits = /* @__PURE__ */ new Map();
var dataDir = process.env.CAATINGA_DATA_DIR || ".online-data";
var originList = new Set((process.env.CAATINGA_ORIGINS || "https://wezzleymaxwel-maker.github.io,http://localhost:5174,http://127.0.0.1:5174").split(",").map((s) => s.trim()));
if (dataDir) {
  await mkdir(dataDir, { recursive: true });
  try {
    const saved = JSON.parse(await readFile(join(dataDir, "rooms.json"), "utf8"));
    for (const data of saved) {
      try {
        const r = Room.restore(data);
        if (Date.now() - r.updatedAt < 864e5) rooms.set(r.code, r);
      } catch {
      }
    }
  } catch {
  }
}
var dirty = false;
var savePromise = null;
function persist() {
  if (savePromise) return savePromise;
  if (!dataDir || !dirty) return Promise.resolve();
  dirty = false;
  savePromise = (async () => {
    try {
      const file = join(dataDir, "rooms.json");
      await writeFile(file + ".tmp", JSON.stringify([...rooms.values()].map((r) => r.dump())), { mode: 384 });
      await rename(file + ".tmp", file);
    } catch (e) {
      dirty = true;
      console.error("N\xE3o foi poss\xEDvel salvar as salas:", e instanceof Error ? e.message : "erro");
    } finally {
      savePromise = null;
    }
  })();
  return savePromise;
}
var shuttingDown = false;
async function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  clearInterval(timer);
  if (savePromise) await savePromise;
  dirty = true;
  await persist();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 2e3).unref();
}
var server = createServer(async (req, res) => {
  const origin = req.headers.origin;
  if (origin && originList.has(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  const reply = (status, data) => {
    res.statusCode = status;
    res.end(JSON.stringify(data));
  };
  if (shuttingDown) return reply(503, { ok: false, error: "O anfitri\xE3o est\xE1 encerrando o servidor." });
  if (origin && !originList.has(origin)) return reply(403, { ok: false, error: "Origem n\xE3o autorizada." });
  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.statusCode = 204;
    return res.end();
  }
  if (req.method === "POST" && req.url === "/host/stop") {
    const secret = process.env.CAATINGA_CONTROL_TOKEN, received = req.headers.authorization, expected = secret ? "Bearer " + secret : "";
    if (!secret || typeof received !== "string" || Buffer.byteLength(received) !== Buffer.byteLength(expected) || !timingSafeEqual(Buffer.from(received), Buffer.from(expected))) return reply(403, { ok: false, error: "Acesso reservado ao iniciador." });
    reply(200, { ok: true });
    void shutdown();
    return;
  }
  if (req.method === "GET" && req.url === "/health") return reply(200, { ok: true, game: "CAATINGA", protocol: 1 });
  if (req.method !== "POST" || req.url !== "/api") return reply(404, { ok: false, error: "N\xE3o encontrado." });
  const ip = req.socket.remoteAddress || "unknown", now = Date.now(), limit = limits.get(ip);
  if (!limit || limit.until < now) limits.set(ip, { count: 1, until: now + 6e4 });
  else if (++limit.count > 600) return reply(429, { ok: false, error: "Muitas solicita\xE7\xF5es. Aguarde um instante." });
  try {
    req.setEncoding("utf8");
    let size = 0, body = "";
    for await (const chunk of req) {
      size += Buffer.byteLength(chunk);
      if (size > 8192) {
        reply(413, { ok: false, error: "Solicita\xE7\xE3o grande demais." });
        req.destroy();
        return;
      }
      body += chunk;
    }
    const a = JSON.parse(body);
    if (!a || typeof a !== "object") throw Error("Solicita\xE7\xE3o inv\xE1lida.");
    if (a.type === "create") {
      if (rooms.size >= 500) throw Error("O servidor est\xE1 cheio. Tente mais tarde.");
      const name = cleanName(a.name);
      let code = "";
      do {
        code = Array.from({ length: 6 }, () => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[randomInt2(32)]).join("");
      } while (rooms.has(code));
      const room2 = new Room(code, void 0, a.options), member = room2.join(name);
      rooms.set(code, room2);
      dirty = true;
      return reply(200, { ok: true, session: { code, token: member.token }, view: room2.view(member.seat) });
    }
    const room = typeof a.code === "string" ? rooms.get(a.code.toUpperCase()) : null;
    if (!room) throw Error("Sala n\xE3o encontrada. Confira o c\xF3digo.");
    if (a.type === "join") {
      const member = room.join(a.name);
      dirty = true;
      return reply(200, { ok: true, session: { code: room.code, token: member.token }, view: room.view(member.seat) });
    }
    const p = room.authenticate(a.token);
    switch (a.type) {
      case "poll":
      case "resume":
        break;
      case "start":
        room.start(p);
        dirty = true;
        break;
      case "action":
        room.command(p, a.command, a.version, a.requestId);
        dirty = true;
        break;
      case "leave":
        room.leave(p);
        dirty = true;
        return reply(200, { ok: true });
      default:
        throw Error("Solicita\xE7\xE3o inv\xE1lida.");
    }
    return reply(200, { ok: true, view: room.view(p) });
  } catch (e) {
    return reply(400, { ok: false, error: e instanceof SyntaxError ? "Solicita\xE7\xE3o inv\xE1lida." : e instanceof Error ? e.message : "N\xE3o foi poss\xEDvel realizar a a\xE7\xE3o." });
  }
});
var timer = setInterval(() => {
  for (const [code, room] of rooms) {
    if (Date.now() - room.updatedAt > 864e5) {
      rooms.delete(code);
      dirty = true;
      continue;
    }
    const version = room.version;
    try {
      room.tick();
    } catch (e) {
      console.error("Erro no turno autom\xE1tico:", e instanceof Error ? e.message : "erro");
    }
    if (room.version !== version) dirty = true;
  }
  for (const [ip, l] of limits) if (l.until < Date.now()) limits.delete(ip);
  void persist();
}, 700);
timer.unref();
var port = Number(process.env.PORT || 8787);
server.listen(port, process.env.CAATINGA_HOST || "0.0.0.0", () => console.log(`CAATINGA online na porta ${port}`));
for (const signal of ["SIGINT", "SIGTERM"]) process.on(signal, () => {
  void shutdown();
});
